function SayMyName(props){
    return (
        <div>
            <p>Fala ai {props.nome}, suave?</p>
        </div>
    )
}

export default SayMyName