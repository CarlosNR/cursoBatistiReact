import Frase from "./Frase"

function HelloWorld(){

    return (
        <div>
            <h1>Meu primeiro componente</h1>
            <h2>Componente de componente</h2>
            <Frase/>
        </div>

    )

}

export default HelloWorld