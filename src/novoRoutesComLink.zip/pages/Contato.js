import { LoremIpsum } from "react-lorem-ipsum"
function Contato(){
    return(
        <div>
            <h1>Contato</h1>
            <p><LoremIpsum/></p>
        </div>
    )
}

export default Contato