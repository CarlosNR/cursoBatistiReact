import { LoremIpsum } from "react-lorem-ipsum"
function Empresa(){
    return(
        <div>
            <h1>Empresa</h1>
            <p><LoremIpsum/></p>
        </div>
    )
}

export default Empresa