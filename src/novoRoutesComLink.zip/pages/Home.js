import { LoremIpsum } from "react-lorem-ipsum"
function Home(){
    return(
        <div>
            <h1>Homepage</h1>
            <p><LoremIpsum/></p>
        </div>
    )
}

export default Home